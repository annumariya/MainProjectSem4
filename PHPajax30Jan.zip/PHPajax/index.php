<?php
include "dbconnect.php";
if (isset($_POST["submit"]))
{
$vcountry=$_POST["country"];


mysqli_query($con,"INSERT INTO country(`cname`)VALUES ('$vcountry')");

}
?>
<html>
<head>
<body>
<form action=# method="POST">
Enter Country Name:
<input type="textbox" name="country" id="country"><br>
<input type ="submit" name="submit" id="submit">
</form>
</body>
</head>
</html>