<html>
<head>
<body>
<form action=# method="POST">
Select Country<select>
<option >Select</option>
</select><br>
Enter State Name:
<input type="textbox" name="country" id="country"><br>
<input type ="submit" name="submit" id="submit">
</form>
</body>
</head>
</html>