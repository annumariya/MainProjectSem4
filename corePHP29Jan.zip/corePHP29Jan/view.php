
<?php
if (isset($_POST["submit"]))
{
$vname=$_POST["uname"];
$vemail=$_POST["uemail"];


echo $vname;
echo $vemail;
}
?>

