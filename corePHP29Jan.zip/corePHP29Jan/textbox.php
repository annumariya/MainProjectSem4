 
<?php
if (isset($_POSTT["submit"]))
{
$vname=$_POSTT["uname"];
$vemail=$_POSTT["uemail"];


echo $vname;
echo $vemail;
}
?>

<html>
<head>
</head>
<body>
<form action="view.php"  method="GET">
Name<input type="text" name="uname" id ="name" ><br><br>
Email<input type="text" name="uemail" id "email">
<input type ="submit" name="submit" id= "submit">
</body>
</html>