<html>
<head>
</head>
<body>
<form action="#"  method="POST">
<table border="2">
<tr><th>Sl.No</th>
<th>Name</th>
<th>Address</th>
<th>phone</th>
</tr>
<table>


</body>
</html>