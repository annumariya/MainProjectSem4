
<html>
<head>
</head>
<body>
  <?php
  echo "hai";
  $a="Annu";
  echo "</br>";
  echo $a;
  $a=100;echo $a;
  echo "</br>";
$b=100; echo $b;
echo "</br>";
$c =$a +$b;
echo "sum is $c";
?>
</body>
</html>