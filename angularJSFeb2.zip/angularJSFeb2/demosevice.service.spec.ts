import { TestBed } from '@angular/core/testing';

import { DemoseviceService } from './demosevice.service';

describe('DemoseviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DemoseviceService = TestBed.get(DemoseviceService);
    expect(service).toBeTruthy();
  });
});
