<?php
		include("dbconnect.php");
		header("Access-Control-Allow-Origin:*");
		header("Access-Control-Allow-Methods:PUT,GET,POST");
		header("Access-Control-Allow-Headers:Origin,X-Requester-With,Content-Type,Accept");
	


	$postdata=file_get_contents("php://input");
	$request=json_decode($postdata);
	$name=mysqli_real_escape_string($con,trim(request->data->name));
	$uname=mysqli_real_escape_string($con,trim(request->data->uname));
	$password=mysqli_real_escape_string($con,trim(request->data->password));
	$query="INSERT INTO `angularlogin`(`name`,`username`,`password`) VALUES ('$name','$uname','$password')";
	if(mysqli_query($con,$query))
	{
		$student=['name'->$name,
		'uname'->$uname,
		'password'->$password
	
	id->mysqli_insert_id($con)];
	echo json_encode(['data'=>$student]);
	}

?>
