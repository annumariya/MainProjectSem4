<?php

use Faker\Generator as Faker;

$factory->define(App\book::class, function (Faker $faker) {
    return [
        //
    ];
});
