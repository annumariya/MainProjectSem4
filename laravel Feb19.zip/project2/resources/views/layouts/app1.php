<html>
<head></head>
<body>
<div>
<a href="/index">Index</a>
<a href="/about">about</a>
<a href="/service">services</a>
</div>
@yield('content');