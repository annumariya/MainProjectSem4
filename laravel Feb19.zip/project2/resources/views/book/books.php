<html>
<for method="post" action="">
<title></title>
<input type="text" name="title"><br>
<br>
<body>
<input type="text" name="body">
<button type="submit">add</button>
</form>
</body>