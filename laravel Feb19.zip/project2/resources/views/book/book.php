<form method="post" action="{{"
<div class="form-group"
<label for="name">title</label>
<button type='submit'>add</button>
</form>
