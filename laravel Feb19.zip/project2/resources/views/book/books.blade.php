<html>
<form method="post" action="{{route('book.store')}}">
@csrf
<title></title>
Title<input type="text" name="title"><br>
<br>
<body>
Body<input type="text" name="body"><br>
<br>
Author<input type="text" name="author"><br>
<br>
<button type="submit" name="sub">ADD</button>
</form>
</html>