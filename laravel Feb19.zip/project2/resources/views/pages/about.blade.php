@extends('layouts.app1')
@section('content')
<h1>About</h1>
<p>this is my about page</p>
@endsection