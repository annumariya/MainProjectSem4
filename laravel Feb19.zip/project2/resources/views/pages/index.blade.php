@extends('layouts.app1')
@section('content')
<h1>index</h1>
<h2>{{$name}}</h2>
<p>this is my index page</p>
@endsection