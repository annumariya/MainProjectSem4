@extends('layouts.app1')
@section('content')
<h1>services</h1>
<p>this is my service page</p>
@endsection